package com.VTI.frontend;


import com.VTI.backend.Static_Test;

public class Program_Static {
    public static void main(String[] args) {
        Static_Test.Question_1();
        Static_Test.Question_2();
        Static_Test.Question_3();
        Static_Test.Question_5();
        Static_Test.Question_6();
    }

}

