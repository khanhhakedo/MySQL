package com.VTI.frontend;

import com.VTI.backend.IO_Stream;

import java.io.IOException;

public class Program_IO_Stream {
    public static void main(String[] args) throws IOException {
        IO_Stream.Question1();
        IO_Stream.Question2();
        IO_Stream.Question3();

    }
}
