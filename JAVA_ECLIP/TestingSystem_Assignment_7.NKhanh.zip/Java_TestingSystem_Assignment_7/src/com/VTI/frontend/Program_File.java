package com.VTI.frontend;

import com.VTI.backend.File_Test;

import java.io.File;
import java.io.IOException;

public class Program_File {
    public static void main(String[] args) throws IOException {
//        File_Test.Question1();
//        File_Test.Question2();
//        File_Test.Question3();
//        File_Test.Question5();
//        File_Test.Question6();
//        File_Test.Question7();
//        File_Test.Question8();
//        File_Test.Question9();






    }
}
