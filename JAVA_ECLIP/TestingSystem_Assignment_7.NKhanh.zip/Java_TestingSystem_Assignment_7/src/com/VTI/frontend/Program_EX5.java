package com.VTI.frontend;

import com.VTI.backend.Exercise5_Test;
import com.VTI.entity.Exercise5.Student_Exercise5;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Program_EX5 {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        //         Doc file
Exercise5_Test.Question1();

    }
}
