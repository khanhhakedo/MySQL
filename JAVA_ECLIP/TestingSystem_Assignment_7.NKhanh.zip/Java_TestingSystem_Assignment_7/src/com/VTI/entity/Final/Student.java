package com.VTI.entity.Final;

public class Student {
    private final  int id = 0;
    private  String name;

    public final void hocBai(){
        System.out.println("Dang hoc bai");
    }

}
