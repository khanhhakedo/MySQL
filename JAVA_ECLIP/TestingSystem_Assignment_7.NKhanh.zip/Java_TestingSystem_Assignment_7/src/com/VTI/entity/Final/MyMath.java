package com.VTI.entity.Final;

public class MyMath {
    private  final  float PI = (float) 3.14;

    public float Sum(int a){
       return a +PI;

    }
}
