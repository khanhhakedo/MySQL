package com.VTI.entity.Static_Test;

public class SecondaryStudent extends Student_5{
}
