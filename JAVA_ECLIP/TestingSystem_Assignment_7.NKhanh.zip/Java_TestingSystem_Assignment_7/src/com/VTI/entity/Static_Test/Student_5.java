package com.VTI.entity.Static_Test;


public class Student_5 {
    public  int id;
    public String name;
    public String clazz;


}
