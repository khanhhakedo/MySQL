package com.VTI.entity.Static_Test;

public class PrimaryStudent extends  Student_5{
}
