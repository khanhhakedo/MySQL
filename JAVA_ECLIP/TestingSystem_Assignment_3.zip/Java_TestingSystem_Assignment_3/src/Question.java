import java.util.Date;

public class Question {
	int questionId;
	String content;
	CategoryQuestion category_ID;
	TypeQuestion type_ID;
	Account creator_ID;
	Date createDate;
}
