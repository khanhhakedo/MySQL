
public class CategoryQuestion {
	int categoryId;
	String categoryName;
}
