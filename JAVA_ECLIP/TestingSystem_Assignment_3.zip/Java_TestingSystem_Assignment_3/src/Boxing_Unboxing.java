
public class Boxing_Unboxing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//		Question 1:
	//			Khởi tạo lương có datatype là Integer có giá trị bằng 5000.
	//			Sau đó convert lương ra float và hiển thị lương lên màn hình (với số float có 2 số
		//		sau dấu thập phân)
		
//		Integer salary = 5000;
//		float salaryconvert = salary.floatValue();
//			
//		System.out.printf("%2.2f", salaryconvert);
	
	//		Question 2:
	//		Khai báo 1 String có value = "1234567"
	//		Hãy convert String đó ra số int
		
//		String Question2 = "1234567";
//		Integer Question_2 = Integer.parseInt(Question2);
//		System.out.println(Question_2);
		
		
		
	//		Question 3:
	//		Khởi tạo 1 số Integer có value là chữ "1234567"
	//		Sau đó convert số trên thành datatype int
		
//		Integer Question3 = 1234567;
//		int Question_3 = Question3.intValue();
//		System.out.println(Question_3);
//		
	}

}
