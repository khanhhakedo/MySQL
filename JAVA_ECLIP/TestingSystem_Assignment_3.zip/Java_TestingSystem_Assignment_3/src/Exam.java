
import java.time.LocalTime;
import java.util.Date;

public class Exam {
	byte examId;
	byte code;
	String title;
	CategoryQuestion category_ID;
	LocalTime duration;
	Account creator_Id;
	Date createDate;
}
