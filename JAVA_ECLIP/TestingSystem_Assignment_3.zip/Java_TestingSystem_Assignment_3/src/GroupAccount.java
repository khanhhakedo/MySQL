import java.util.Date;

public class GroupAccount {
		Group group_ID;
		Account[] accountIDs;
		Date joinDates;
}
