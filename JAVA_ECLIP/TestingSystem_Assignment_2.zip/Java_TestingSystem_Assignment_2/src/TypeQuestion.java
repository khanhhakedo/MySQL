
public class TypeQuestion {
	byte typeId;
	TypeName typeName;
}
