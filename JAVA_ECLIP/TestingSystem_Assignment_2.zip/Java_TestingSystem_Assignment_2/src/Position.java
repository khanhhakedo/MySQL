

public class Position {
	int positionId;
	positionName positionName;
}
