
public class Department {
	int departmentId;
	String departmentName;
}
