import java.util.Date;

public class Group {
byte groupId;
String groupName;
Account creatorID;
Date createDate;
}
