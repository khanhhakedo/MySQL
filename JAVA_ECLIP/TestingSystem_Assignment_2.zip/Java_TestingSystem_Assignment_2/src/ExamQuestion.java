
public class ExamQuestion {
	Exam exam_ID;
	Question[] questionIDs;
}

