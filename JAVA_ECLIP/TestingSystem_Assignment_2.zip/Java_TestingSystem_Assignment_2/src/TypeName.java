
public enum TypeName {
	ESSAY,MULTIPLE_CHOICE;
}
