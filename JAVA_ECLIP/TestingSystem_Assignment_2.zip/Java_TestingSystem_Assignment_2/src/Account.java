import java.util.Date;

public class Account {
	int accountId;
	String email;
	String userName;
	String fullName;
	Department departmentID;
	Position positionID;
	Group[] groups;
	Date createDate;
}
