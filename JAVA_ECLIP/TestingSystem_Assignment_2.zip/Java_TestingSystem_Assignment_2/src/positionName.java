
public enum positionName {
	DEV,TEST,SCRUM_MASTER,PM;
}
