
public class Answer {
int answerId;
String content;
Question question_ID;
boolean isCorrect;
}
