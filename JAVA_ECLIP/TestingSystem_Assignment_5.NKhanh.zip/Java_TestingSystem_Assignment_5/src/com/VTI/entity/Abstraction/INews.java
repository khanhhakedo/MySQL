package com.VTI.entity.Abstraction;

public interface INews {
    void Display();

    float Calculate();
}
