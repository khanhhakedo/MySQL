package com.VTI.entity.Optional;

public interface IStudent {
    void diemdanh();
    void hocbai();
    void donVeSinh();
}
