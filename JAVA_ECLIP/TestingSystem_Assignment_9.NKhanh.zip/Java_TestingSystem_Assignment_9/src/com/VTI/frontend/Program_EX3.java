package com.VTI.frontend;

import com.VTI.backend.Exercise3;

public class Program_EX3 {
    public static void main(String[] args) {
        Exercise3.Question1();
        Exercise3.Question2();

    }
}
