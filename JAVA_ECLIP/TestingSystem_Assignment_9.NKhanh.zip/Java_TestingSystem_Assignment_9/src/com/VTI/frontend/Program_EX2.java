package com.VTI.frontend;

import com.VTI.backend.Exercise2;

public class Program_EX2 {
    public static void main(String[] args) {
        Exercise2.Question1();
        Exercise2.Question2();
    }
}
